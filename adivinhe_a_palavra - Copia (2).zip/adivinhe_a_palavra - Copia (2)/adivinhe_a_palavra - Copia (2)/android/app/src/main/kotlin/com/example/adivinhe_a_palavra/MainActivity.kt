package com.example.adivinhe_a_palavra

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
