import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_service.dart';


class TelaSala extends StatelessWidget {
  final String codigo;
  const TelaSala({super.key, required this.codigo});

  String textoStatus(String status) {
    switch (status) {
      case 'waiting':
        return 'Aguardando Jogador 2...';
      case 'playing':
        return 'Em andamento';
      case 'won':
        return 'Jogador 2 venceu!';
      default:
        return 'Jogador 2 perdeu!';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sua Sala')),
      body: StreamBuilder(
        stream: servico.sala(codigo), 
        builder: (context, snapshot) {
          final sala = snapshot.data?.data();
          if (sala == null) return const Center(child: CircularProgressIndicator());

          final status = sala['status'] as String;
          final usadas = List<String>.from(sala['usedLetters']);
          final terminou = status == 'won' || status == 'lost';

          return SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (status == 'waiting') ...[
                  const Text('Sala criada!',
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                ],
                Text('Código: $codigo',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Tema: ${sala['theme']}'),
                        const SizedBox(height: 8),
                        Text('Jogador 2: ${sala['player2Name'] ?? '-'}'),
                        const SizedBox(height: 8),
                        Text('Erros: ${sala['currentErrors']} / ${sala['maxErrors']}'),
                        const SizedBox(height: 8),
                        Text('Letras: ${usadas.isEmpty ? '-' : usadas.join(', ')}'),
                        const SizedBox(height: 8),
                        Text('Status: ${textoStatus(status)}'),
                        if (terminou) ...[
                          const SizedBox(height: 8),
                          Text('A palavra era: ${sala['word']}'),
                        ],
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Histórico lido da subcoleção rooms/{codigo}/jogadas.
                const Text('Histórico de jogadas',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                  stream: servico.historicoJogadas(codigo),
                  builder: (context, snap) {
                    if (snap.hasError) return Text('Erro: ${snap.error}');
                    final jogadas = snap.data?.docs ?? [];
                    if (jogadas.isEmpty) return const Text('Nenhuma jogada ainda.');
                    return Column(
                      children: jogadas.map((d) {
                        final j = d.data();
                        final acertou = j['acertou'] == true;
                        return ListTile(
                          dense: true,
                          leading: Icon(acertou ? Icons.check_circle : Icons.cancel,
                              color: acertou ? Colors.green : Colors.red),
                          title: Text('${j['jogadorNome']} escolheu "${j['letra']}"'),
                          subtitle: Text(acertou ? 'Acertou' : 'Errou'),
                        );
                      }).toList(),
                    );
                  },
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Voltar para o início'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
