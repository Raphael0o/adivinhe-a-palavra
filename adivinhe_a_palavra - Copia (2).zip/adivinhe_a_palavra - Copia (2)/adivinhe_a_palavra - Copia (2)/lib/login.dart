import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'firebase_service.dart';
import 'cadastro.dart';

class TelaLogin extends StatefulWidget {
  const TelaLogin({super.key});

  @override
  State<TelaLogin> createState() => _TelaLoginState();
}

class _TelaLoginState extends State<TelaLogin> {
  final emailCtrl = TextEditingController();
  final senhaCtrl = TextEditingController();
  String erro = '';
  bool carregando = false;

  @override
  void initState() {
    super.initState();
    _carregarEmail();
  }


  Future<void> _carregarEmail() async {
    final prefs = await SharedPreferences.getInstance();
    final salvo = prefs.getString('email_salvo') ?? '';
    if (mounted) setState(() => emailCtrl.text = salvo);
  }


  Future<void> _salvarEmail(String email) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('email_salvo', email);
  }

  Future<void> entrar() async {
    setState(() { carregando = true; erro = ''; });
    try {
      await servico.entrar(emailCtrl.text.trim(), senhaCtrl.text);
      await _salvarEmail(emailCtrl.text.trim());

    } catch (e) {
      setState(() => erro = mensagemErro(e));
    }
    if (mounted) setState(() => carregando = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Adivinha a Palavra')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: emailCtrl,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(labelText: 'E-mail', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: senhaCtrl,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Senha', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            if (erro.isNotEmpty) Text(erro, style: const TextStyle(color: Colors.red)),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: carregando ? null : entrar,
              child: const Text('Entrar'),
            ),
            TextButton(
              onPressed: () => Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const TelaCadastro())),
              child: const Text('Criar conta'),
            ),
          ],
        ),
      ),
    );
  }
}
