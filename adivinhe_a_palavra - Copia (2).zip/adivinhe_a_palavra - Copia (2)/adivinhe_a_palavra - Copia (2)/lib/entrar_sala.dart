import 'package:flutter/material.dart';
import 'firebase_service.dart';
import 'jogo.dart';

class TelaEntrarSala extends StatefulWidget {
  const TelaEntrarSala({super.key});

  @override
  State<TelaEntrarSala> createState() => _TelaEntrarSalaState();
}

class _TelaEntrarSalaState extends State<TelaEntrarSala> {
  final codigoCtrl = TextEditingController();
  String erro = '';
  bool carregando = false;

  Future<void> entrar() async {
    final codigo = codigoCtrl.text.trim().toUpperCase();
    if (codigo.isEmpty) {
      setState(() => erro = 'Digite o código da sala.');
      return;
    }
    setState(() { carregando = true; erro = ''; });
    try {
      final mensagem = await servico.entrarNaSala(codigo);
      if (!mounted) return;
      if (mensagem != null) {
        setState(() => erro = mensagem); 
      } else {
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (_) => TelaJogo(codigo: codigo)));
        return;
      }
    } catch (e) {
      setState(() => erro = 'Erro ao entrar na sala.');
    }
    if (mounted) setState(() => carregando = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Entrar em uma Sala')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: codigoCtrl,
              textCapitalization: TextCapitalization.characters,
              decoration: const InputDecoration(
                  labelText: 'Código da sala', hintText: 'A7K92', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            if (erro.isNotEmpty) Text(erro, style: const TextStyle(color: Colors.red)),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: carregando ? null : entrar,
              child: const Text('Entrar'),
            ),
          ],
        ),
      ),
    );
  }
}
