import 'package:flutter/material.dart';
import 'firebase_service.dart';
import 'sala.dart';

class TelaCriarSala extends StatefulWidget {
  const TelaCriarSala({super.key});

  @override
  State<TelaCriarSala> createState() => _TelaCriarSalaState();
}

class _TelaCriarSalaState extends State<TelaCriarSala> {
  final temaCtrl = TextEditingController();
  final palavraCtrl = TextEditingController();
  final dicaCtrl = TextEditingController();
  final errosCtrl = TextEditingController(text: '5');
  bool temAcentos = false;
  String erro = '';
  bool carregando = false;

  Future<void> criar() async {
    final tema = temaCtrl.text.trim();
    final palavra = palavraCtrl.text.trim().toUpperCase(); 
    final dica = dicaCtrl.text.trim();
    final maxErros = int.tryParse(errosCtrl.text) ?? 0;

    if (tema.isEmpty || palavra.isEmpty || dica.isEmpty) {
      setState(() => erro = 'Preencha tema, palavra e dica.');
      return;
    }
    if (!RegExp(r'^[A-ZÁÀÂÃÉÊÍÓÔÕÚÇ ]+$').hasMatch(palavra)) {
      setState(() => erro = 'A palavra deve ter apenas letras.');
      return;
    }
    if (!temAcentos && regexAcento.hasMatch(palavra)) {
      setState(() => erro = 'A palavra tem acento ou ç. Marque "Sim".');
      return;
    }
    if (maxErros < 1) {
      setState(() => erro = 'O máximo de erros deve ser pelo menos 1.');
      return;
    }

    setState(() { carregando = true; erro = ''; });
    try {
      final codigo = await servico.criarSala(
        tema: tema,
        palavra: palavra,
        dica: dica,
        maxErros: maxErros,
        temAcentos: temAcentos,
      );
      if (!mounted) return;
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => TelaSala(codigo: codigo)));
    } catch (e) {
      setState(() { erro = 'Erro ao criar a sala.'; carregando = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Criar Sala')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: temaCtrl,
              decoration: const InputDecoration(
                  labelText: 'Tema', hintText: 'Animais', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: palavraCtrl,
              decoration: const InputDecoration(
                  labelText: 'Palavra', hintText: 'ELEFANTE', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: dicaCtrl,
              decoration: const InputDecoration(
                  labelText: 'Dica',
                  hintText: 'É um animal terrestre de grande porte.',
                  border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            const Text('Máximo de erros'),
            Row(
              children: [3, 5, 7, 10]
                  .map((n) => Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ActionChip(
                          label: Text('$n'),
                          onPressed: () => setState(() => errosCtrl.text = '$n'),
                        ),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: errosCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                  labelText: 'Ou digite outro número', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            const Text('A palavra possui acentos ou ç?'),
            const SizedBox(height: 4),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: true, label: Text('Sim')),
                ButtonSegment(value: false, label: Text('Não')),
              ],
              selected: {temAcentos},
              onSelectionChanged: (v) => setState(() => temAcentos = v.first),
            ),
            const SizedBox(height: 12),
            if (erro.isNotEmpty) Text(erro, style: const TextStyle(color: Colors.red)),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: carregando ? null : criar,
                child: const Text('Criar Sala'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
