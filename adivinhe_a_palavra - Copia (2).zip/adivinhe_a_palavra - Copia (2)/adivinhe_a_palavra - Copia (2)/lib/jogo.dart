import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_service.dart';

// Tela do Jogador 2: escolhe as letras.
class TelaJogo extends StatelessWidget {
  final String codigo;
  const TelaJogo({super.key, required this.codigo});

  static const letrasBasicas = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  static const letrasExtras = 'ÁÀÂÃÉÊÍÓÔÕÚÇ';


  String montarPalavra(String palavra, List<String> usadas) {
    final partes = palavra.split('').map((c) {
      if (!regexLetra.hasMatch(c)) return c; 
      return usadas.contains(c) ? c : '_';
    });
    return partes.join(' ');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Adivinha a Palavra')),
      body: StreamBuilder(
        stream: servico.sala(codigo),
        builder: (context, snapshot) {
          final sala = snapshot.data?.data();
          if (sala == null) return const Center(child: CircularProgressIndicator());

          final palavra = sala['word'] as String;
          final status = sala['status'] as String;
          final usadas = List<String>.from(sala['usedLetters']);
          final jogando = status == 'playing';

          final letras = (letrasBasicas + (sala['hasAccents'] == true ? letrasExtras : '')).split('');

          
          return Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 500),
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            Text('Tema: ${sala['theme']}', style: const TextStyle(fontSize: 18)),
                            const SizedBox(height: 8),
                            Text('Dica: ${sala['hint']}'),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      montarPalavra(palavra, usadas),
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, letterSpacing: 2),
                    ),
                    const SizedBox(height: 16),
                    Text('Erros: ${sala['currentErrors']} / ${sala['maxErrors']}',
                        style: const TextStyle(fontSize: 20)),
                    const SizedBox(height: 8),

                   
                    StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                      stream: servico.letrasErradas(codigo),
                      builder: (context, snap) {
                        final erradas = (snap.data?.docs ?? [])
                            .map((d) => d.data()['letra'] as String)
                            .toList();
                        return Text(
                          'Letras erradas: ${erradas.isEmpty ? '-' : erradas.join(', ')}',
                          style: const TextStyle(color: Colors.red),
                        );
                      },
                    ),
                    const SizedBox(height: 16),

          
                    if (status == 'won' || status == 'lost') ...[
                      Card(
                        color: status == 'won' ? Colors.green[100] : Colors.red[100],
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            children: [
                              Text(
                                status == 'won' ? 'Você descobriu a palavra!' : 'Você perdeu!',
                                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 8),
                              Text('A palavra era: $palavra', style: const TextStyle(fontSize: 18)),
                              const SizedBox(height: 12),
                              ElevatedButton(
                                onPressed: () => Navigator.pop(context),
                                child: const Text('Voltar para o início'),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                    ],

                  
                    Wrap(
                      alignment: WrapAlignment.center,
                      spacing: 6,
                      runSpacing: 6,
                      children: letras.map((letra) {
                        final bloqueada = !jogando || usadas.contains(letra);
                        return SizedBox(
                          width: 48,
                          height: 48,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(padding: EdgeInsets.zero),
                            onPressed: bloqueada ? null : () => servico.escolherLetra(codigo, letra),
                            child: Text(letra, style: const TextStyle(fontSize: 18)),
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}