import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_service.dart';
import 'criar_sala.dart';
import 'entrar_sala.dart';
import 'sala.dart';
import 'jogo.dart';

class TelaHome extends StatelessWidget {
  const TelaHome({super.key});

  String textoStatus(String status) {
    switch (status) {
      case 'waiting':
        return 'Aguardando Jogador 2';
      case 'playing':
        return 'Em andamento';
      case 'won':
        return 'Jogador 2 venceu';
      default:
        return 'Jogador 2 perdeu';
    }
  }


  Future<void> _entrarDaLista(BuildContext context, String codigo) async {
    try {
      final msg = await servico.entrarNaSala(codigo);
      if (!context.mounted) return;
      if (msg != null) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
        return;
      }
      Navigator.push(
          context, MaterialPageRoute(builder: (_) => TelaJogo(codigo: codigo)));
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Erro ao entrar na sala.')));
    }
  }

  Widget _titulo(String texto) => Padding(
        padding: const EdgeInsets.only(top: 24, bottom: 8),
        child: Text(texto, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Adivinha a Palavra')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 500),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
              
                Center(
                  child: StreamBuilder(
                    stream: servico.usuario(),
                    builder: (context, snapshot) {
                      final nome = snapshot.data?.data()?['username'] ?? '';
                      return Text('Olá, $nome!',
                          style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold));
                    },
                  ),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => Navigator.push(
                        context, MaterialPageRoute(builder: (_) => const TelaCriarSala())),
                    child: const Text('Criar Sala'),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => Navigator.push(
                        context, MaterialPageRoute(builder: (_) => const TelaEntrarSala())),
                    child: const Text('Entrar com código'),
                  ),
                ),


                _titulo('Salas abertas'),
                StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                  stream: servico.salasAbertas(),
                  builder: (context, snapshot) {
                    if (snapshot.hasError) {
                      return Text('Erro ao carregar salas: ${snapshot.error}');
                    }
                    if (!snapshot.hasData) {
                      return const Center(child: CircularProgressIndicator());
                    }
    
                    final docs = snapshot.data!.docs
                        .where((d) => d.data()['player1'] != servico.uid)
                        .toList();
                    if (docs.isEmpty) return const Text('Nenhuma sala aberta no momento.');
                    return Column(
                      children: docs.map((d) {
                        final s = d.data();
                        return Card(
                          child: ListTile(
                            title: Text('Tema: ${s['theme']}'),
                            subtitle: Text('Criada por ${s['player1Name']} • Código ${d.id}'),
                            trailing: const Icon(Icons.play_arrow),
                            onTap: () => _entrarDaLista(context, d.id),
                          ),
                        );
                      }).toList(),
                    );
                  },
                ),

     
                _titulo('Minhas salas'),
                StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                  stream: servico.minhasSalas(),
                  builder: (context, snapshot) {
                    if (snapshot.hasError) {
                      return Text('Erro ao carregar salas: ${snapshot.error}');
                    }
                    if (!snapshot.hasData) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    final docs = snapshot.data!.docs;
                    if (docs.isEmpty) return const Text('Você ainda não criou salas.');
                    return Column(
                      children: docs.map((d) {
                        final s = d.data();
                        return Card(
                          child: ListTile(
                            title: Text('${s['theme']} • ${d.id}'),
                            subtitle: Text(textoStatus(s['status'] as String)),
                            trailing: const Icon(Icons.chevron_right),
                            onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(builder: (_) => TelaSala(codigo: d.id))),
                          ),
                        );
                      }).toList(),
                    );
                  },
                ),

                const SizedBox(height: 24),
                Center(
                  child: TextButton(
                    onPressed: () => servico.sair(),
                    child: const Text('Sair'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
