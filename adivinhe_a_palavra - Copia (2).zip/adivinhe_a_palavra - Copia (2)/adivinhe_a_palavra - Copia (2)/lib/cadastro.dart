import 'package:flutter/material.dart';
import 'firebase_service.dart';

class TelaCadastro extends StatefulWidget {
  const TelaCadastro({super.key});

  @override
  State<TelaCadastro> createState() => _TelaCadastroState();
}

class _TelaCadastroState extends State<TelaCadastro> {
  final nomeCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final senhaCtrl = TextEditingController();
  final confirmaCtrl = TextEditingController();
  String erro = '';
  bool carregando = false;

  Future<void> criarConta() async {
    if (nomeCtrl.text.trim().isEmpty) {
      setState(() => erro = 'Digite um nome de usuário.');
      return;
    }
    if (senhaCtrl.text != confirmaCtrl.text) {
      setState(() => erro = 'As senhas não são iguais.');
      return;
    }
    setState(() { carregando = true; erro = ''; });
    try {
      await servico.cadastrar(nomeCtrl.text.trim(), emailCtrl.text.trim(), senhaCtrl.text);
      
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() => erro = mensagemErro(e));
    }
    if (mounted) setState(() => carregando = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Criar conta')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(
              controller: nomeCtrl,
              decoration: const InputDecoration(labelText: 'Nome de usuário', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: emailCtrl,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(labelText: 'E-mail', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: senhaCtrl,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Senha', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: confirmaCtrl,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Confirmar senha', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            if (erro.isNotEmpty) Text(erro, style: const TextStyle(color: Colors.red)),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: carregando ? null : criarConta,
              child: const Text('Criar conta'),
            ),
          ],
        ),
      ),
    );
  }
}
