import 'dart:math';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


final RegExp regexLetra = RegExp(r'[A-ZÁÀÂÃÉÊÍÓÔÕÚÇ]');
final RegExp regexAcento = RegExp(r'[ÁÀÂÃÉÊÍÓÔÕÚÇ]');


bool palavraDescoberta(String palavra, List<String> usadas) {
  for (final c in palavra.split('')) {
    if (regexLetra.hasMatch(c) && !usadas.contains(c)) return false;
  }
  return true;
}


String mensagemErro(Object e) {
  if (e is FirebaseAuthException) {
    switch (e.code) {
      case 'email-already-in-use':
        return 'Este e-mail já está cadastrado.';
      case 'invalid-email':
        return 'E-mail inválido.';
      case 'weak-password':
        return 'A senha deve ter pelo menos 6 caracteres.';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'E-mail ou senha incorretos.';
      default:
        return 'Erro: ${e.code}';
    }
  }
  return 'Ocorreu um erro. Tente novamente.';
}


class FirebaseService {
  final _auth = FirebaseAuth.instance;
  final _db = FirebaseFirestore.instance;

  String get uid => _auth.currentUser!.uid;

  
  Future<void> cadastrar(String username, String email, String senha) async {
    final cred = await _auth.createUserWithEmailAndPassword(email: email, password: senha);
    await _db.collection('users').doc(cred.user!.uid).set({
      'username': username,
      'email': email,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> entrar(String email, String senha) async {
    await _auth.signInWithEmailAndPassword(email: email, password: senha);
  }

  Future<void> sair() async {
    await _auth.signOut();
  }

  
  Stream<DocumentSnapshot<Map<String, dynamic>>> usuario() {
    return _db.collection('users').doc(uid).snapshots();
  }

  Future<String> nomeUsuario() async {
    final doc = await _db.collection('users').doc(uid).get();
    return doc.data()?['username'] ?? '';
  }

  
  Future<String> _gerarCodigo() async {
    const caracteres = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final random = Random();
    while (true) {
      final codigo = List.generate(5, (_) => caracteres[random.nextInt(caracteres.length)]).join();
      final doc = await _db.collection('rooms').doc(codigo).get();
      if (!doc.exists) return codigo;
    }
  }

 
  Future<String> criarSala({
    required String tema,
    required String palavra,
    required String dica,
    required int maxErros,
    required bool temAcentos,
  }) async {
    final codigo = await _gerarCodigo();
    await _db.collection('rooms').doc(codigo).set({
      'player1': uid,
      'player1Name': await nomeUsuario(),
      'player2': null,
      'player2Name': null,
      'theme': tema,
      'word': palavra,
      'hint': dica,
      'hasAccents': temAcentos,
      'maxErrors': maxErros,
      'currentErrors': 0,
      'usedLetters': <String>[],
      'status': 'waiting',
    });
    return codigo;
  }


  Future<String?> entrarNaSala(String codigo) async {
    final ref = _db.collection('rooms').doc(codigo);
    final nome = await nomeUsuario();
    return _db.runTransaction<String?>((t) async {
      final snap = await t.get(ref);
      if (!snap.exists) return 'Sala não encontrada.';
      final sala = snap.data()!;
      if (sala['player1'] == uid) return 'Você é o criador desta sala.';
      if (sala['player2'] == uid) return null; 
      if (sala['player2'] != null) return 'Sala cheia.';
      t.update(ref, {'player2': uid, 'player2Name': nome, 'status': 'playing'});
      return null;
    });
  }


  Stream<DocumentSnapshot<Map<String, dynamic>>> sala(String codigo) {
    return _db.collection('rooms').doc(codigo).snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> salasAbertas() {
    return _db.collection('rooms').where('status', isEqualTo: 'waiting').snapshots();
  }


  Stream<QuerySnapshot<Map<String, dynamic>>> minhasSalas() {
    return _db.collection('rooms').where('player1', isEqualTo: uid).snapshots();
  }


  Stream<QuerySnapshot<Map<String, dynamic>>> letrasErradas(String codigo) {
    return _db
        .collection('rooms')
        .doc(codigo)
        .collection('jogadas')
        .where('acertou', isEqualTo: false)
        .snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> historicoJogadas(String codigo) {
    return _db
        .collection('rooms')
        .doc(codigo)
        .collection('jogadas')
        .orderBy('criadoEm')
        .snapshots();
  }

  Future<void> escolherLetra(String codigo, String letra) async {
    final ref = _db.collection('rooms').doc(codigo);
    await _db.runTransaction((t) async {
      final snap = await t.get(ref);
      final sala = snap.data()!;

      if (sala['status'] != 'playing') return; 
      final usadas = List<String>.from(sala['usedLetters']);
      if (usadas.contains(letra)) return; 

      final palavra = sala['word'] as String;
      int erros = sala['currentErrors'];
      usadas.add(letra);
      if (!palavra.contains(letra)) erros++; 

      String status = 'playing';
      if (palavraDescoberta(palavra, usadas)) {
        status = 'won';
      } else if (erros >= sala['maxErrors']) {
        status = 'lost';
      }

      t.update(ref, {'usedLetters': usadas, 'currentErrors': erros, 'status': status});

      t.set(ref.collection('jogadas').doc(), {
        'letra': letra,
        'acertou': palavra.contains(letra),
        'jogador': uid,
        'jogadorNome': sala['player2Name'] ?? '',
        'criadoEm': FieldValue.serverTimestamp(),
      });
    });
  }
}

final servico = FirebaseService();
