import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError('Plataforma não configurada.');
    }
  }



  static const FirebaseOptions android = FirebaseOptions(
     apiKey: "AIzaSyBbkxHLdmgUJmM5vuBLP103xmMrzBXKD0M",
  authDomain: "pdm-raphael.firebaseapp.com",
  projectId: "pdm-raphael",
  storageBucket: "pdm-raphael.firebasestorage.app",
  messagingSenderId: "905817832751",
  appId: "1:905817832751:web:13938ed5ec2c4c649875da"
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: "AIzaSyBbkxHLdmgUJmM5vuBLP103xmMrzBXKD0M",
  authDomain: "pdm-raphael.firebaseapp.com",
  projectId: "pdm-raphael",
  storageBucket: "pdm-raphael.firebasestorage.app",
  messagingSenderId: "905817832751",
  appId: "1:905817832751:web:13938ed5ec2c4c649875da"
  );

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: "AIzaSyBbkxHLdmgUJmM5vuBLP103xmMrzBXKD0M",
  authDomain: "pdm-raphael.firebaseapp.com",
  projectId: "pdm-raphael",
  storageBucket: "pdm-raphael.firebasestorage.app",
  messagingSenderId: "905817832751",
  appId: "1:905817832751:web:13938ed5ec2c4c649875da"
  );
}
